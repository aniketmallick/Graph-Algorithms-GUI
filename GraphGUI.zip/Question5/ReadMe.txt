Graph Algorithms GUI: Developed a desktop software which helps in drawing and editing the graphs by mouse click and keyboard
interrupts in GUI mode. Various operations can be selected using buttons provided, like shortest path between two vertices in the graph 
can be computed using the provided objects(shapes). On loading the queries, objects will move graphically from the initial to final 
vertices along the shortest path, implemented using Dijkstra’s algorithm.